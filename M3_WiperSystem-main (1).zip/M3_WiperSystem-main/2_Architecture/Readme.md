
## Flow chart 

![flowwiper](https://user-images.githubusercontent.com/101174057/167923605-5b7a6dcc-20da-40a4-923f-0bb71637ba14.png)


## Structural diagram 

![structural](https://user-images.githubusercontent.com/101174057/167923856-3066018e-aab3-4bb1-ab80-f976023ccdec.png) 

# Block Diagram:
![BLOCK DIAGRAM (1)](https://user-images.githubusercontent.com/101699116/168216608-1d2c05db-9c7e-4cdb-9908-47f6503dd69f.png)
