# M3_WiperSystem 

# INTRDUCTION
Wiper system is the utility project. It is used to clean the wind shield of the car at the front and rear. Wiper works by removing oil,dust,rain water and dirt.That get struck to the wind shield and the arm is provided by the motor.The warm gear is able to generate the force required to move the wipers as fast as they need to move. now a days we have an automatic wiper control when ever we stop wiping in between the process it will automatically comes to initial position this is the new wiper system as behined in the wiper arm.The car wipers that have been available in the present day market are manual systems that work on the principle of manual switching.Our proposed system proposes an automatic wiper system that automatically switches ON the wiper on detection of rain and stops the wiper action when rain stops. This system eases the work of driver by eliminating the manual human intervention for initiating the wiper action, thereby contributing to the comfort driving.
This Wiper Speed Control System is utilised in all sorts of automobiles, and its primary function is to remove rain air drops from the vehicle's front screen. Because driving a vehicle in the rain is quite difficult, we will use wipers to clear the front screen of the vehicle, which is a mirror, so that we may drive the vehicle even in the rain.

### Folder Structure
| Folder | Description |
| ----- | ----- |
|0_Abstract|about project|
| 1_Requirements | Documents detailing requirements and  research |
| 2_Architecture | Documents specifying design details |
| 3_Implementation | All code and documentation |
| 4_TestCases | Documents with test plans and procedures |
| 5_Report | Documentation of the whole Project |
| 6_Output | Output of the Project |
 
 ## Codiga Badges
 
![Quality](https://api.codiga.io/project/33350/score/svg)

  ![Quality](https://api.codiga.io/project/33350/status/svg) 
  
  ## Codacy
  [![Codacy Badge](https://app.codacy.com/project/badge/Grade/25cf0013a76a4f6380b7c4e97df98b33)](https://www.codacy.com/gh/akkivanguu/M3_WiperSystem/dashboard?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=akkivanguu/M3_WiperSystem&amp;utm_campaign=Badge_Grade)
  ## code QL
  [![CodeQL](https://github.com/akkivanguu/M3_WiperSystem/actions/workflows/c-quality.yml/badge.svg)](https://github.com/akkivanguu/M3_WiperSystem/actions/workflows/c-quality.yml)
