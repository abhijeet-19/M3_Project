

## Test Plans

## High level test plan
| ID | Description | Expected O/P | Actual O/P | Type of test |
| --- | --- | --- | --- | --- |
| H_01 | Wiper is moving along the windshield	| PASSED | SUCCESS | Scenario |
| H_02 | Wiper is comes to rest at the end |	PASSED |	SUCCESS |	Boundary|

| ID | Description | Input | Output | Status |
| --- | --- | --- | --- | --- |
| L\_01 | Button Pressed | input = 2 sec | Red LED ON  | PASS |
| L\_02 | Button Pressed | input = 1 sec | Blue LED ON  | PASS |
| L\_03 | Button Pressed | input = 0.25 sec | Green LED ON  | PASS |
| L\_04 | Button Pressed | input = 0.125 sec | Orange LED ON  | PASS |
| L\_05 | Button Pressed | input = 2 sec| Red LED OFF  | PASS |

