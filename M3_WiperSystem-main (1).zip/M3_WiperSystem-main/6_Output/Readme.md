
# OUTPUT

## 1. Button pressed once for two seconds
![on](https://user-images.githubusercontent.com/101030179/168251121-8df7fd82-7ebb-4e77-9e31-d89c19f239c7.png)


## 2. Button  pressed once again for two seconds
* Car is on ACC mode that means car turned off.
![2](https://user-images.githubusercontent.com/101174057/167471797-064b7e26-b759-406b-a06f-d0ad0b37e4e6.png)

## 3. Button pressed for second time
* Wiper turned on.
![3](https://user-images.githubusercontent.com/101174057/167471813-450ece14-5020-4a9d-a4f4-a8d41955ab58.png)

## 4. Button pressed for thrd time
* Wiper turned off. 
![4](https://user-images.githubusercontent.com/101174057/167471826-916c1217-138d-4ebe-abf3-507395863fa4.png)

